#!/bin/bash

g++ driver.cpp -o FSM
./FSM < input.in
