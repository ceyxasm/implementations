#!/bin/bash
clear
g++ server.cpp -o server
g++ client.cpp -o client
./server

